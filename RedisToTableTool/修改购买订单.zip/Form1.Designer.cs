﻿namespace RedisToTableTool
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.txb_UserRangeStart = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txb_UserRangeEnd = new System.Windows.Forms.TextBox();
            this.lbl_showMessage = new System.Windows.Forms.Label();
            this.txb_AssertRangeStart = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txb_AssertRangeEnd = new System.Windows.Forms.TextBox();
            this.btn_start = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txb_userFNums = new System.Windows.Forms.TextBox();
            this.txb_userSNums = new System.Windows.Forms.TextBox();
            this.txb_assetFNums = new System.Windows.Forms.TextBox();
            this.txb_assetSNums = new System.Windows.Forms.TextBox();
            this.ck_User = new System.Windows.Forms.CheckBox();
            this.ck_Asset = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.gb_auzer = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ck_IsFromAzureData = new System.Windows.Forms.CheckBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsb_CheckUserAssetInfo = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tsb_checkAssetInfo = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.gb_auzer.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txb_UserRangeStart
            // 
            this.txb_UserRangeStart.Font = new System.Drawing.Font("微软雅黑", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_UserRangeStart.Location = new System.Drawing.Point(140, 23);
            this.txb_UserRangeStart.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txb_UserRangeStart.Name = "txb_UserRangeStart";
            this.txb_UserRangeStart.Size = new System.Drawing.Size(173, 27);
            this.txb_UserRangeStart.TabIndex = 10;
            this.txb_UserRangeStart.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 91);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(125, 20);
            this.label1.TabIndex = 6;
            this.label1.Text = "资产RangeStart：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(319, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "用户RangeEnd：";
            // 
            // txb_UserRangeEnd
            // 
            this.txb_UserRangeEnd.Font = new System.Drawing.Font("微软雅黑", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_UserRangeEnd.Location = new System.Drawing.Point(445, 23);
            this.txb_UserRangeEnd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txb_UserRangeEnd.Name = "txb_UserRangeEnd";
            this.txb_UserRangeEnd.Size = new System.Drawing.Size(173, 27);
            this.txb_UserRangeEnd.TabIndex = 10;
            this.txb_UserRangeEnd.Text = "0";
            // 
            // lbl_showMessage
            // 
            this.lbl_showMessage.AutoSize = true;
            this.lbl_showMessage.Font = new System.Drawing.Font("微软雅黑", 8.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_showMessage.ForeColor = System.Drawing.Color.Red;
            this.lbl_showMessage.Location = new System.Drawing.Point(119, 528);
            this.lbl_showMessage.Name = "lbl_showMessage";
            this.lbl_showMessage.Size = new System.Drawing.Size(0, 17);
            this.lbl_showMessage.TabIndex = 6;
            // 
            // txb_AssertRangeStart
            // 
            this.txb_AssertRangeStart.Font = new System.Drawing.Font("微软雅黑", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_AssertRangeStart.Location = new System.Drawing.Point(140, 87);
            this.txb_AssertRangeStart.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txb_AssertRangeStart.Name = "txb_AssertRangeStart";
            this.txb_AssertRangeStart.Size = new System.Drawing.Size(173, 27);
            this.txb_AssertRangeStart.TabIndex = 10;
            this.txb_AssertRangeStart.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(319, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "资产RangeEnd：";
            // 
            // txb_AssertRangeEnd
            // 
            this.txb_AssertRangeEnd.Font = new System.Drawing.Font("微软雅黑", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_AssertRangeEnd.Location = new System.Drawing.Point(445, 87);
            this.txb_AssertRangeEnd.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txb_AssertRangeEnd.Name = "txb_AssertRangeEnd";
            this.txb_AssertRangeEnd.Size = new System.Drawing.Size(173, 27);
            this.txb_AssertRangeEnd.TabIndex = 10;
            this.txb_AssertRangeEnd.Text = "0";
            // 
            // btn_start
            // 
            this.btn_start.Location = new System.Drawing.Point(7, 520);
            this.btn_start.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_start.Name = "btn_start";
            this.btn_start.Size = new System.Drawing.Size(106, 32);
            this.btn_start.TabIndex = 11;
            this.btn_start.Text = "开始运行";
            this.btn_start.UseVisualStyleBackColor = true;
            this.btn_start.Click += new System.EventHandler(this.btn_start_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 307);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(191, 20);
            this.label5.TabIndex = 12;
            this.label5.Text = "插入用户资产关系成功数量：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(3, 368);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(191, 20);
            this.label6.TabIndex = 12;
            this.label6.Text = "插入用户资产关系失败数量：";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(3, 419);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(191, 20);
            this.label7.TabIndex = 12;
            this.label7.Text = "插入资产用户关系成功数量：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(3, 478);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(191, 20);
            this.label8.TabIndex = 12;
            this.label8.Text = "插入资产用户关系失败数量：";
            // 
            // txb_userFNums
            // 
            this.txb_userFNums.Enabled = false;
            this.txb_userFNums.Font = new System.Drawing.Font("微软雅黑", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_userFNums.Location = new System.Drawing.Point(200, 364);
            this.txb_userFNums.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txb_userFNums.Name = "txb_userFNums";
            this.txb_userFNums.Size = new System.Drawing.Size(472, 27);
            this.txb_userFNums.TabIndex = 10;
            this.txb_userFNums.Text = "0";
            // 
            // txb_userSNums
            // 
            this.txb_userSNums.Enabled = false;
            this.txb_userSNums.Font = new System.Drawing.Font("微软雅黑", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_userSNums.Location = new System.Drawing.Point(200, 303);
            this.txb_userSNums.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txb_userSNums.Name = "txb_userSNums";
            this.txb_userSNums.Size = new System.Drawing.Size(472, 27);
            this.txb_userSNums.TabIndex = 10;
            this.txb_userSNums.Text = "0";
            // 
            // txb_assetFNums
            // 
            this.txb_assetFNums.Enabled = false;
            this.txb_assetFNums.Font = new System.Drawing.Font("微软雅黑", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_assetFNums.Location = new System.Drawing.Point(200, 478);
            this.txb_assetFNums.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txb_assetFNums.Name = "txb_assetFNums";
            this.txb_assetFNums.Size = new System.Drawing.Size(472, 27);
            this.txb_assetFNums.TabIndex = 10;
            this.txb_assetFNums.Text = "0";
            // 
            // txb_assetSNums
            // 
            this.txb_assetSNums.Enabled = false;
            this.txb_assetSNums.Font = new System.Drawing.Font("微软雅黑", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txb_assetSNums.Location = new System.Drawing.Point(200, 415);
            this.txb_assetSNums.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txb_assetSNums.Name = "txb_assetSNums";
            this.txb_assetSNums.Size = new System.Drawing.Size(472, 27);
            this.txb_assetSNums.TabIndex = 10;
            this.txb_assetSNums.Text = "0";
            // 
            // ck_User
            // 
            this.ck_User.AutoSize = true;
            this.ck_User.Checked = true;
            this.ck_User.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ck_User.Font = new System.Drawing.Font("微软雅黑", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ck_User.Location = new System.Drawing.Point(323, 22);
            this.ck_User.Name = "ck_User";
            this.ck_User.Size = new System.Drawing.Size(210, 24);
            this.ck_User.TabIndex = 13;
            this.ck_User.Text = "资产用户关系是否使用多线程";
            this.ck_User.UseVisualStyleBackColor = true;
            // 
            // ck_Asset
            // 
            this.ck_Asset.AutoSize = true;
            this.ck_Asset.Checked = true;
            this.ck_Asset.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ck_Asset.Font = new System.Drawing.Font("微软雅黑", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ck_Asset.Location = new System.Drawing.Point(553, 22);
            this.ck_Asset.Name = "ck_Asset";
            this.ck_Asset.Size = new System.Drawing.Size(210, 24);
            this.ck_Asset.TabIndex = 13;
            this.ck_Asset.Text = "用户资产关系是否使用多线程";
            this.ck_Asset.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(9, 27);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "用户RangeStart：";
            // 
            // gb_auzer
            // 
            this.gb_auzer.Controls.Add(this.txb_UserRangeEnd);
            this.gb_auzer.Controls.Add(this.label1);
            this.gb_auzer.Controls.Add(this.label3);
            this.gb_auzer.Controls.Add(this.txb_UserRangeStart);
            this.gb_auzer.Controls.Add(this.label2);
            this.gb_auzer.Controls.Add(this.txb_AssertRangeStart);
            this.gb_auzer.Controls.Add(this.label4);
            this.gb_auzer.Controls.Add(this.txb_AssertRangeEnd);
            this.gb_auzer.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gb_auzer.Location = new System.Drawing.Point(0, 140);
            this.gb_auzer.Name = "gb_auzer";
            this.gb_auzer.Size = new System.Drawing.Size(827, 142);
            this.gb_auzer.TabIndex = 14;
            this.gb_auzer.TabStop = false;
            this.gb_auzer.Text = "使用Table中数据分类";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ck_IsFromAzureData);
            this.groupBox2.Controls.Add(this.ck_User);
            this.groupBox2.Controls.Add(this.ck_Asset);
            this.groupBox2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(0, 28);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(827, 106);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "配置选择";
            // 
            // ck_IsFromAzureData
            // 
            this.ck_IsFromAzureData.AutoSize = true;
            this.ck_IsFromAzureData.Font = new System.Drawing.Font("微软雅黑", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ck_IsFromAzureData.Location = new System.Drawing.Point(13, 22);
            this.ck_IsFromAzureData.Name = "ck_IsFromAzureData";
            this.ck_IsFromAzureData.Size = new System.Drawing.Size(266, 24);
            this.ck_IsFromAzureData.TabIndex = 13;
            this.ck_IsFromAzureData.Text = "是否从文本文件中获取需要插入的数据";
            this.ck_IsFromAzureData.UseVisualStyleBackColor = true;
            this.ck_IsFromAzureData.CheckedChanged += new System.EventHandler(this.ck_IsFromAzureData_CheckedChanged);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsb_CheckUserAssetInfo,
            this.toolStripSeparator1,
            this.toolStripButton1,
            this.toolStripSeparator3,
            this.tsb_checkAssetInfo,
            this.toolStripSeparator2,
            this.toolStripButton2,
            this.toolStripSeparator5,
            this.toolStripButton4,
            this.toolStripSeparator7,
            this.toolStripButton3,
            this.toolStripButton5,
            this.toolStripSeparator4,
            this.toolStripButton6});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1010, 25);
            this.toolStrip1.TabIndex = 16;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsb_CheckUserAssetInfo
            // 
            this.tsb_CheckUserAssetInfo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsb_CheckUserAssetInfo.Image = ((System.Drawing.Image)(resources.GetObject("tsb_CheckUserAssetInfo.Image")));
            this.tsb_CheckUserAssetInfo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsb_CheckUserAssetInfo.Name = "tsb_CheckUserAssetInfo";
            this.tsb_CheckUserAssetInfo.Size = new System.Drawing.Size(161, 22);
            this.tsb_CheckUserAssetInfo.Text = "验证单个redis资产订单信息";
            this.tsb_CheckUserAssetInfo.Click += new System.EventHandler(this.tsb_CheckUserAssetInfo_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(125, 22);
            this.toolStripButton1.Text = "ReloadTableToDisk";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // tsb_checkAssetInfo
            // 
            this.tsb_checkAssetInfo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsb_checkAssetInfo.Image = ((System.Drawing.Image)(resources.GetObject("tsb_checkAssetInfo.Image")));
            this.tsb_checkAssetInfo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsb_checkAssetInfo.Name = "tsb_checkAssetInfo";
            this.tsb_checkAssetInfo.Size = new System.Drawing.Size(108, 22);
            this.tsb_checkAssetInfo.Text = "验证磁盘资产信息";
            this.tsb_checkAssetInfo.Click += new System.EventHandler(this.tsb_checkAssetInfo_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(60, 22);
            this.toolStripButton2.Text = "修复数据";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.Size = new System.Drawing.Size(86, 22);
            this.toolStripButton4.Text = "获取特定Json";
            this.toolStripButton4.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.Size = new System.Drawing.Size(85, 22);
            this.toolStripButton3.Text = "ProcessDebt";
            this.toolStripButton3.Click += new System.EventHandler(this.toolStripButton3_Click_1);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.Size = new System.Drawing.Size(141, 22);
            this.toolStripButton5.Text = "UpdateDataFromBank";
            this.toolStripButton5.Click += new System.EventHandler(this.toolStripButton5_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.Size = new System.Drawing.Size(175, 22);
            this.toolStripButton6.Text = "UpdateYemUserProductInfo";
            this.toolStripButton6.Click += new System.EventHandler(this.toolStripButton6_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1010, 560);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.gb_auzer);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btn_start);
            this.Controls.Add(this.txb_assetSNums);
            this.Controls.Add(this.txb_userSNums);
            this.Controls.Add(this.txb_assetFNums);
            this.Controls.Add(this.txb_userFNums);
            this.Controls.Add(this.lbl_showMessage);
            this.Font = new System.Drawing.Font("微软雅黑", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "数据更新至Table小工具";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gb_auzer.ResumeLayout(false);
            this.gb_auzer.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txb_UserRangeStart;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txb_UserRangeEnd;
        private System.Windows.Forms.Label lbl_showMessage;
        private System.Windows.Forms.TextBox txb_AssertRangeStart;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txb_AssertRangeEnd;
        private System.Windows.Forms.Button btn_start;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txb_userFNums;
        private System.Windows.Forms.TextBox txb_userSNums;
        private System.Windows.Forms.TextBox txb_assetFNums;
        private System.Windows.Forms.TextBox txb_assetSNums;
        private System.Windows.Forms.CheckBox ck_User;
        private System.Windows.Forms.CheckBox ck_Asset;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox gb_auzer;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox ck_IsFromAzureData;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton tsb_checkAssetInfo;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton tsb_CheckUserAssetInfo;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
    }
}

