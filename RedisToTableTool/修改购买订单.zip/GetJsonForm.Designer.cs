﻿namespace RedisToTableTool
{
    partial class GetJsonForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txb_NewUserAseetRatioId = new System.Windows.Forms.TextBox();
            this.btn_GetJsonData = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txb_DebtToTransferId = new System.Windows.Forms.TextBox();
            this.txb_purchaseNotifyJson = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txb_RansomOrderId = new System.Windows.Forms.TextBox();
            this.ck_1 = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_purchaseNotify = new System.Windows.Forms.Button();
            this.btn_redeemNotify = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txb_redeemNotifyJson = new System.Windows.Forms.TextBox();
            this.txb_F1 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txb_S1 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btn_AllDebug = new System.Windows.Forms.Button();
            this.lbl_showMsg = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txb_NewUserAseetRatioId
            // 
            this.txb_NewUserAseetRatioId.Location = new System.Drawing.Point(190, 56);
            this.txb_NewUserAseetRatioId.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txb_NewUserAseetRatioId.Name = "txb_NewUserAseetRatioId";
            this.txb_NewUserAseetRatioId.Size = new System.Drawing.Size(344, 27);
            this.txb_NewUserAseetRatioId.TabIndex = 16;
            // 
            // btn_GetJsonData
            // 
            this.btn_GetJsonData.Location = new System.Drawing.Point(268, 148);
            this.btn_GetJsonData.Margin = new System.Windows.Forms.Padding(9);
            this.btn_GetJsonData.Name = "btn_GetJsonData";
            this.btn_GetJsonData.Size = new System.Drawing.Size(123, 35);
            this.btn_GetJsonData.TabIndex = 14;
            this.btn_GetJsonData.Text = "GetJsonData";
            this.btn_GetJsonData.UseVisualStyleBackColor = true;
            this.btn_GetJsonData.Click += new System.EventHandler(this.btn_GetJsonData_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(28, 59);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 20);
            this.label1.TabIndex = 15;
            this.label1.Text = "NewUserAssetRatioId:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(53, 109);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 20);
            this.label2.TabIndex = 15;
            this.label2.Text = "DebtToTransferId:";
            // 
            // txb_DebtToTransferId
            // 
            this.txb_DebtToTransferId.Location = new System.Drawing.Point(190, 106);
            this.txb_DebtToTransferId.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txb_DebtToTransferId.Name = "txb_DebtToTransferId";
            this.txb_DebtToTransferId.Size = new System.Drawing.Size(344, 27);
            this.txb_DebtToTransferId.TabIndex = 16;
            // 
            // txb_purchaseNotifyJson
            // 
            this.txb_purchaseNotifyJson.Location = new System.Drawing.Point(12, 250);
            this.txb_purchaseNotifyJson.Multiline = true;
            this.txb_purchaseNotifyJson.Name = "txb_purchaseNotifyJson";
            this.txb_purchaseNotifyJson.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txb_purchaseNotifyJson.Size = new System.Drawing.Size(549, 222);
            this.txb_purchaseNotifyJson.TabIndex = 17;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(65, 5);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 20);
            this.label3.TabIndex = 15;
            this.label3.Text = "RansomOrderId:";
            // 
            // txb_RansomOrderId
            // 
            this.txb_RansomOrderId.Location = new System.Drawing.Point(190, 5);
            this.txb_RansomOrderId.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txb_RansomOrderId.Name = "txb_RansomOrderId";
            this.txb_RansomOrderId.Size = new System.Drawing.Size(344, 27);
            this.txb_RansomOrderId.TabIndex = 16;
            // 
            // ck_1
            // 
            this.ck_1.AutoSize = true;
            this.ck_1.Location = new System.Drawing.Point(76, 154);
            this.ck_1.Name = "ck_1";
            this.ck_1.Size = new System.Drawing.Size(37, 24);
            this.ck_1.TabIndex = 18;
            this.ck_1.Text = "1";
            this.ck_1.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(120, 155);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(123, 20);
            this.label4.TabIndex = 15;
            this.label4.Text = "选√则是1 不选为2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(13, 213);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(152, 20);
            this.label5.TabIndex = 15;
            this.label5.Text = "购买成功通知交易系统:";
            // 
            // btn_purchaseNotify
            // 
            this.btn_purchaseNotify.Location = new System.Drawing.Point(573, 437);
            this.btn_purchaseNotify.Margin = new System.Windows.Forms.Padding(9);
            this.btn_purchaseNotify.Name = "btn_purchaseNotify";
            this.btn_purchaseNotify.Size = new System.Drawing.Size(97, 35);
            this.btn_purchaseNotify.TabIndex = 14;
            this.btn_purchaseNotify.Text = "执行";
            this.btn_purchaseNotify.UseVisualStyleBackColor = true;
            this.btn_purchaseNotify.Click += new System.EventHandler(this.btn_purchaseNotify_Click);
            // 
            // btn_redeemNotify
            // 
            this.btn_redeemNotify.Location = new System.Drawing.Point(573, 714);
            this.btn_redeemNotify.Margin = new System.Windows.Forms.Padding(9);
            this.btn_redeemNotify.Name = "btn_redeemNotify";
            this.btn_redeemNotify.Size = new System.Drawing.Size(97, 35);
            this.btn_redeemNotify.TabIndex = 14;
            this.btn_redeemNotify.Text = "执行";
            this.btn_redeemNotify.UseVisualStyleBackColor = true;
            this.btn_redeemNotify.Click += new System.EventHandler(this.btn_redeemNotify_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(13, 490);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(152, 20);
            this.label6.TabIndex = 15;
            this.label6.Text = "赎回成功通知交易系统:";
            // 
            // txb_redeemNotifyJson
            // 
            this.txb_redeemNotifyJson.Location = new System.Drawing.Point(12, 527);
            this.txb_redeemNotifyJson.Multiline = true;
            this.txb_redeemNotifyJson.Name = "txb_redeemNotifyJson";
            this.txb_redeemNotifyJson.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txb_redeemNotifyJson.Size = new System.Drawing.Size(549, 222);
            this.txb_redeemNotifyJson.TabIndex = 17;
            // 
            // txb_F1
            // 
            this.txb_F1.Enabled = false;
            this.txb_F1.Location = new System.Drawing.Point(690, 54);
            this.txb_F1.Name = "txb_F1";
            this.txb_F1.Size = new System.Drawing.Size(368, 27);
            this.txb_F1.TabIndex = 21;
            this.txb_F1.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(605, 59);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 20);
            this.label7.TabIndex = 19;
            this.label7.Text = "失败数量：";
            // 
            // txb_S1
            // 
            this.txb_S1.Enabled = false;
            this.txb_S1.Location = new System.Drawing.Point(690, 5);
            this.txb_S1.Name = "txb_S1";
            this.txb_S1.Size = new System.Drawing.Size(368, 27);
            this.txb_S1.TabIndex = 22;
            this.txb_S1.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(605, 12);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 20);
            this.label8.TabIndex = 20;
            this.label8.Text = "成功数量：";
            // 
            // btn_AllDebug
            // 
            this.btn_AllDebug.Location = new System.Drawing.Point(690, 102);
            this.btn_AllDebug.Margin = new System.Windows.Forms.Padding(9);
            this.btn_AllDebug.Name = "btn_AllDebug";
            this.btn_AllDebug.Size = new System.Drawing.Size(83, 35);
            this.btn_AllDebug.TabIndex = 14;
            this.btn_AllDebug.Text = "批量执行";
            this.btn_AllDebug.UseVisualStyleBackColor = true;
            this.btn_AllDebug.Click += new System.EventHandler(this.btn_AllDebug_Click);
            // 
            // lbl_showMsg
            // 
            this.lbl_showMsg.AutoSize = true;
            this.lbl_showMsg.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_showMsg.Location = new System.Drawing.Point(686, 163);
            this.lbl_showMsg.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_showMsg.Name = "lbl_showMsg";
            this.lbl_showMsg.Size = new System.Drawing.Size(40, 20);
            this.lbl_showMsg.TabIndex = 15;
            this.lbl_showMsg.Text = "提示:";
            // 
            // GetJsonForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1111, 788);
            this.Controls.Add(this.txb_F1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txb_S1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.ck_1);
            this.Controls.Add(this.txb_redeemNotifyJson);
            this.Controls.Add(this.txb_purchaseNotifyJson);
            this.Controls.Add(this.txb_DebtToTransferId);
            this.Controls.Add(this.txb_RansomOrderId);
            this.Controls.Add(this.txb_NewUserAseetRatioId);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lbl_showMsg);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btn_redeemNotify);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_purchaseNotify);
            this.Controls.Add(this.btn_AllDebug);
            this.Controls.Add(this.btn_GetJsonData);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("微软雅黑", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "GetJsonForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GetJsonForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txb_NewUserAseetRatioId;
        private System.Windows.Forms.Button btn_GetJsonData;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txb_DebtToTransferId;
        private System.Windows.Forms.TextBox txb_purchaseNotifyJson;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txb_RansomOrderId;
        private System.Windows.Forms.CheckBox ck_1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_purchaseNotify;
        private System.Windows.Forms.Button btn_redeemNotify;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txb_redeemNotifyJson;
        private System.Windows.Forms.TextBox txb_F1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txb_S1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btn_AllDebug;
        private System.Windows.Forms.Label lbl_showMsg;
    }
}