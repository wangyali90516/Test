﻿namespace RedisToTableTool.Model
{
    public class CgYemOrderInfo
    {
        public string ORDER_NO { get; set; }
        public long ORG_AMOUNT { get; set; }
        public string PAY_USER_OUT_ID { get; set; }
        public string SOURCE_ORDER_ID { get; set; }
    }
}