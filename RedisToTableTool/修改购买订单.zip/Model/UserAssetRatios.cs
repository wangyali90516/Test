﻿namespace RedisToTableTool.Model
{
    /// <summary>
    ///     用户资产比例表
    /// </summary>
    public class UserAssetRatios
    {
        //Id
        //    UserAssetRatioId
        //UserId
        //    UserName
        //AssetId
        //    Numerator
        //Denominator
        //    UserPresentValue
        //DeductedAmount
        //    AddAmount
        //DiffDays
        //    Comment
        //VisualStyleElement.Status
        //    Reserve
        //UpdatedBy
        //    UpdatedTime
        //CreatedBy
        //    CreatedTime
        //IsDeleted
        //    SequenceNo
        //OrderId
        //    OrderTime
        //IsReturned
        //    BillDueDate
        //AssetCategoryCode
        //    Capital
        //Cellphone
        //    CredentialNo
        //IsInvestSuccess
        //    IsNotifyTradingSuccess
        //NotifyTradingRespInfo
        //    NotifyTradingTime
        //OriginalUserAssetRatioId
        //    PurchaseMoney
    }
}